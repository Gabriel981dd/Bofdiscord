# Regras de exemplo
