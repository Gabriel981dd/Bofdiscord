package com.redutobase.launcher;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    private static final String PREF_NAME = "launcher_session";
    private final SharedPreferences prefs;

    public SessionManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public void saveLogin(String username) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("logged", true);
        editor.putString("username", username);
        editor.apply();
    }

    public boolean isLogged() {
        return prefs.getBoolean("logged", false);
    }

    public String getUsername() {
        return prefs.getString("username", "Jogador");
    }

    public void logout() {
        prefs.edit().clear().apply();
    }
}
