package com.redutobase.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        final EditText edtUser = (EditText) findViewById(R.id.edtRegUsername);
        final EditText edtEmail = (EditText) findViewById(R.id.edtRegEmail);
        final EditText edtPass = (EditText) findViewById(R.id.edtRegPassword);
        Button btnRegister = (Button) findViewById(R.id.btnRegister);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = edtUser.getText().toString().trim();
                String email = edtEmail.getText().toString().trim();
                String pass = edtPass.getText().toString().trim();

                if (user.length() == 0 || email.length() == 0 || pass.length() == 0) {
                    Toast.makeText(RegisterActivity.this, "Preencha todos os campos.", Toast.LENGTH_SHORT).show();
                    return;
                }

                Toast.makeText(RegisterActivity.this, "Cadastro local concluído: " + user, Toast.LENGTH_LONG).show();
                finish();
            }
        });
    }
}
