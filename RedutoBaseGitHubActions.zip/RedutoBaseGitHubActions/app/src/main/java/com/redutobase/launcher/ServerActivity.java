package com.redutobase.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class ServerActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_server);

        TextView txtServerInfo = (TextView) findViewById(R.id.txtServerInfo);
        txtServerInfo.setText(
            "Nome: Reduto Base RP\n" +
            "IP: " + AppConstants.SERVER_IP + "\n" +
            "Porta: " + AppConstants.SERVER_PORT + "\n" +
            "Status: ONLINE\n" +
            "Players: 57/300"
        );
    }
}
