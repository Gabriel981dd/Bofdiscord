package com.redutobase.launcher;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final SessionManager session = new SessionManager(this);
        TextView txtWelcome = (TextView) findViewById(R.id.txtWelcome);
        TextView txtServerStatus = (TextView) findViewById(R.id.txtServerStatus);
        Button btnPlay = (Button) findViewById(R.id.btnPlay);
        Button btnServers = (Button) findViewById(R.id.btnServers);
        Button btnLogout = (Button) findViewById(R.id.btnLogout);

        txtWelcome.setText("Bem-vindo, " + session.getUsername());
        txtServerStatus.setText("Reduto Base RP\nONLINE • 57/300\nIP: " + AppConstants.SERVER_IP + ":" + AppConstants.SERVER_PORT);

        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Aqui você liga o downloader ou cliente do jogo.", Toast.LENGTH_LONG).show();
            }
        });

        btnServers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ServerActivity.class));
            }
        });

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                session.logout();
                startActivity(new Intent(MainActivity.this, LoginActivity.class));
                finish();
            }
        });
    }
}
