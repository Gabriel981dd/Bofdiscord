package com.redutobase.launcher;

public final class AppConstants {
    public static final String BASE_URL = "https://seu-dominio.com/api/";
    public static final String SERVER_IP = "127.0.0.1";
    public static final int SERVER_PORT = 7777;

    private AppConstants() {
    }
}
