package com.redutobase.launcher;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends Activity {
    private EditText edtUsername;
    private EditText edtPassword;
    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        session = new SessionManager(this);
        edtUsername = (EditText) findViewById(R.id.edtUsername);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
        Button btnLogin = (Button) findViewById(R.id.btnLogin);
        Button btnOffline = (Button) findViewById(R.id.btnOffline);
        TextView txtGoRegister = (TextView) findViewById(R.id.txtGoRegister);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doLogin();
            }
        });

        btnOffline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = edtUsername.getText().toString().trim();
                if (user.length() == 0) {
                    user = "Jogador";
                }
                session.saveLogin(user);
                startActivity(new Intent(LoginActivity.this, MainActivity.class));
                finish();
            }
        });

        txtGoRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
            }
        });
    }

    private void doLogin() {
        String user = edtUsername.getText().toString().trim();
        String pass = edtPassword.getText().toString().trim();

        if (user.length() == 0 || pass.length() == 0) {
            Toast.makeText(this, "Preencha usuário e senha.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Login local simples para AIDE.
        // Troque depois por requisição HTTP real usando HttpURLConnection.
        if (user.equals("admin") && pass.equals("123456")) {
            session.saveLogin(user);
            Toast.makeText(this, "Login realizado com sucesso.", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, MainActivity.class));
            finish();
        } else {
            Toast.makeText(this, "Login inválido. Use admin / 123456 para teste.", Toast.LENGTH_LONG).show();
        }
    }
}
