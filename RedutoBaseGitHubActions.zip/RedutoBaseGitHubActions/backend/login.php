<?php
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$username = isset($input['username']) ? $input['username'] : '';
$password = isset($input['password']) ? $input['password'] : '';

if ($username === 'admin' && $password === '123456') {
    echo json_encode(array(
        'success' => true,
        'message' => 'Login realizado com sucesso.',
        'token' => md5($username . time()),
        'username' => $username
    ));
} else {
    echo json_encode(array(
        'success' => false,
        'message' => 'Usuário ou senha inválidos.'
    ));
}
