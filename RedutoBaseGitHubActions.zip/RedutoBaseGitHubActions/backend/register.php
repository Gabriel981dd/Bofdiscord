<?php
header('Content-Type: application/json');
echo json_encode(array(
    'success' => true,
    'message' => 'Conta criada com sucesso.'
));
