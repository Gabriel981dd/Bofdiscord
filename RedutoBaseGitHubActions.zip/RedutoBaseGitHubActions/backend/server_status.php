<?php
header('Content-Type: application/json');
echo json_encode(array(
    'online' => true,
    'hostname' => 'Reduto Base RP',
    'players' => 57,
    'maxPlayers' => 300
));
